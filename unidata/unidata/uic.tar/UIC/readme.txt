UIC - Unidata Internet Connection
21 June 1995
 5 Feb  1995 updaed nots
Jackie Burhans

This directory contains the tools needed to use UniData as the database
to perform searches via the World Wide Web. In addition I have provided
one example of how this was done on our home page http://www.unidata.com.

DISCLAIMER: These tools are provided for your enjoyment. We don't
actually claim they will work as well for you as they do for us. Nor 
do we promise to support them since they aren't an official product.
However, if you have questions, email me at burhans@unidata.com and
I'll try to do what I can.

Web servers allow the execution of programs via the "cgi-bin" interface.
This lets you execute any type of shell script or program and pass it
arguments. Generally this is done in conjunction with a form that
you define using HTML codes.

The following files and directories are included in this package:

readme.txt    - this file
callub        - a shell script which sets up the environment variables
                and executes the C program (callub.udt) which calls a 
                UniBasic subroutine
callub.udt.c  - The C code to produce the callub.udt binary.
callub.udt.mk - A sample makefile to link in the UniData libraries
                with C code to produce the callub.udt binary.
                DON'T USE THIS FILE. Instead, copy your callbas.mk
                file to callub.udt.mk in your $UDTHOME/work directory.
                Then edit the file and change callbas to callub.udt
                everywhere it occurs. You will also need to change
                the libpath line to point to $UDTHOME/lib. Finally,
                if your makefile contains the following line, delete
                it before you attempt the make command:
                      libpath    = -L$$UDTLIB

httpd.conf    - An excerpt of the configuration file that we use for
                the CERN httpd server. 
                NOTE: The following line allows the CERN server to map
                an URL so that it executes the callub script:
                   Exec    /htbin/*   /unidata/local/cern/cgi-bin/* 
 
solutions.html - The Solutions Directory form page. This shows the
                html codes for producing a form including the following
                code that indicates what cgi-bin program to execute:
                   <form action="/htbin/callub/SEARCH.SOLUTIONS" method=GET>

                NOTE: This indicates it should execute the callub script
                located in the /htbin directory. The /htbin specification
                is translated to the actual directory '/unidata/local/cern/
                cgi-bin' by the Exec statement in the config file.

                When you execute a cgi-bin program, the server makes several
                environment variables available to you (these are exported
                by the callub shell script). In particular, the PATH_INFO
                variable contains everything after /htbin/callub - in this
                case "/SEARCH.SOLUTIONS" -- this is parsed to figure out 
                *which* subroutine to call.
            
                FINAL NOTE: method=GET tells the webserver to pass the
                data entered into the form in the QUERY_STRING environment
                variable. You can parse this in your UniBasic program and
                use this data in your subroutine.

udt           - A UniData account directory which contains:

WEB.BP        - a directory of UniBasic programs including:

CALLUB        - The main UniBasic program that gets called by callub.udt;
                This program reads the environment variables and places
                them in named common. It also sets up some standard 
                variables with HTML tags and places them in named common.
                Finally, it parses the PATH_INFO environment variable
                to figure out which subroutine to call.

WEB.COM.INS   - insert file for named common to be used by web programs

WEB.ERROR     - generic subroutine to call to display error message if
                other programs have problem. Pass it the name of the
                program which encountered the error, the error message and
                the url to which it should provide a link (this can be null).

PARSE.QUERY   - A subroutine to parse the data in the QUERY_STRING
                environment variable. To preserve data, characters
                are changed to their 2 letter hex code, this changes
                them back to the original character.

PARSE.QUERY.POST - same as above but gets the data from the input 
                   stream insted of the QUERY_STRING environment
                   variable. The data will be in the input stream
                   if you use the method=POST instead of method=GET
                   in the <FORM action> url.

MAKE.QUERY  - subroutine to form UniQuery command.

SEARCH.SOLUTIONS -  example program to search SOLUTIONS file and
                    generate html to point to another file. NOTE:
                    this program provides a redirection to a web
                    page. Compare to WEB.ERROR which actually generates
                    a web page. Either method may be used in your programs.
