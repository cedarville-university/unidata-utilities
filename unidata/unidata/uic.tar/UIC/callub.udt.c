#include <stdio.h>
#include <setjmp.h>
#include "/usr/ud/include/share.h"

main()
{
 
udt_init();                  /* initialize udt environment -- only once! */
udt_callub("100");           /* call generic UniBasic subroutine */
udt_shut();                  /* shut down udt environment */


}

int udt_init()
{
   int jmpret, sat;

   /* set up error condition handler */
   U_SET_JMP(jmpret, sat);
   if (!jmpret) {
      udtcallbasic_done(1);
      exit(-1);
   }

   /* init udt */
   udtcallbasic_init(0, 0);
  
   return(0);
   
}

int udt_callub(char *id)
{
   char *rtn;
   int   sts;

   /* call CALLUB subr with 1 argument, the ID */
   sts = U_callbas(&rtn, "CALLUB", 1, &id);
   if (!sts){
      /* only free rtn if the call was successful */
      free(rtn);
   }

   return(sts);
}


int udt_shut()
{
   return udtcallbasic_done(1); /* return value not currently used */
}
